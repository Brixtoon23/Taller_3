package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas extends Cliente
{

	public double IMPUESTO = 0.28;
	
	public void CalcularTarifa()
	{
		
	}
	
	
	protected abstract int calcularCostoBase();
	
	protected abstract double calcularPorcentajeDescuento();
	
	
	protected void calcularDistanciaVuelo()
	{
		
	}
	
	
	protected void calcularValorImpuestos()
	{
		
	}

	
	

}
