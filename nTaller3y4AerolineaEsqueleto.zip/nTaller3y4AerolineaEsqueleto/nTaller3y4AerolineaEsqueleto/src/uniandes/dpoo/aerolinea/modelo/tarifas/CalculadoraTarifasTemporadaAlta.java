package uniandes.dpoo.aerolinea.modelo.tarifas;


public class CalculadoraTarifasTemporadaAlta extends CalculadoraTarifas
{
	protected int COSTO_POR_KM =1000;

	
	CalculadoraTarifasTemporadaAlta()
	{
		
		
	}


	@Override
	protected int calcularCostoBase()
	{
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	protected double calcularPorcentajeDescuento()
	{
		// TODO Auto-generated method stub
		return 0;
	}
	

}
