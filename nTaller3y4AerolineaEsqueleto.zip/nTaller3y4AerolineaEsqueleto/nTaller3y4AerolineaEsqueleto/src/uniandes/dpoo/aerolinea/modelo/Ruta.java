package uniandes.dpoo.aerolinea.modelo;

public class Ruta
{
	private String horaSalida;
	private String horaLlegada;
	private String codigoRuta;
	public Aeropuerto destino;
	public Aeropuerto origen;

	public Ruta(Aeropuerto origen,Aeropuerto destino,String holaSalida,String horaLlegada,String codigoRuta)
	{

	}

	public String getCodigoRuta()
	{
		return codigoRuta;
	}
	
	public Aeropuerto getOrigen()
	{
		return origen;
	}
	
	public Aeropuerto getDestino()
	{
		return destino;
	}
	
	public String getHoraSalida()
	{
		return horaSalida;
	}

	public String getHoraLlegada()
	{
		return horaLlegada;
	}
	public int getDuracion()
	{
		return 0;
	}
	public int getMinutos(String horaCompleta)
	{
		return 0;
	}
	public int getHoras(String horaCompleta)
	{
		return 0;
	}
	

	

	

	

}
