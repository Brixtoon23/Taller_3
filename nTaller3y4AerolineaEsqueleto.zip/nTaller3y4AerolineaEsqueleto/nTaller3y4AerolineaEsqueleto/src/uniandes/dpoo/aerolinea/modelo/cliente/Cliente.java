package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente
{
	
	public List<Tiquete> tiquetesSinUsar;
	
	public List<Tiquete> tiquetesUsados;
	

	public Cliente()
	{
		// TODO Auto-generated constructor stub
	}
	
	public String getTipoCliente()
	{
		return null;
		
	}


	public String getIdentificador()
	{
		return null;
		
	}
	
	
	public void agregarTiquete()
	{
		return;
		
	}
	
	
	public int calcularValorTotalTiquetes()
	{
		return 0;
		
	}
	
	
	public void usarTiquetes(Vuelo vuelo)
	{
		return;
		
	}

}

